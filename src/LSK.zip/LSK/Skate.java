package LSK;

public class Skate extends EngineAndNotRegistrableDevice{
	
}
