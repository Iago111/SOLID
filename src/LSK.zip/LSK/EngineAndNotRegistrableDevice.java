package LSK;

public class EngineAndNotRegistrableDevice {

}
