package LSK;

public class NotEngineTransportationDevice extends TransportationDevice{
	public Trailer trailer;

	void matrikulatu() {
		
	}
}
