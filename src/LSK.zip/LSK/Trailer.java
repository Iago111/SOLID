package LSK;

class Trailer extends NotEngineAndRegistrableDevice {
    @Override
    void matrikulatu() { System.out.println("dwnqdnq");}
}
