package LSK;

class Car extends TransportationDevice {
	 @Override
	 void startEngine() { 
		 ///... 
	 }
}
